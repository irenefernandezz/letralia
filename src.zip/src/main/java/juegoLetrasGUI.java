import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.util.Objects;

public class juegoLetrasGUI extends JFrame {
    private ControladorTablero controladorTablero;
    private ControladorLetra controladorLetra;
    private ControladorPuntos controladorPuntos;

    private JPanel panelTablero;
    private JPanel contenedorInferior;
    private JPanel contenedorSuperior;
    private JPanel panelLetras;
    private JPanel panelFila;

    private JButton[] botones;

    private JButton vocal;
    private JButton consonante;
    private JButton atras;

    private int tamano;
    private boolean primerTurno;
    private char[] letras;
    private boolean tamanoSeleccionado = false;
    private boolean dificultadSeleccionada = false;

    Color gris = new Color(245, 245, 245);    // gris clarito
    Color malva = new Color(180, 150, 255);   // morado suave
    Color negro = new Color(20, 20, 20);       // negro suave
    Color morado = new Color(90, 60, 150); // morado oscuro


    /**
     * Inicialización de la ventana de juego.
     */
    public juegoLetrasGUI() {
        setTitle("Letralia");
        controladorPuntos = new ControladorPuntos();
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(600, 600);
        setLocationRelativeTo(null);

        mostrarMenu();
    }

    /**
     * Creación de los elementos gráficos del menú principal
     */
    private void mostrarMenu() {

        //panel principal del menú.
        JPanel panelMenu = new JPanel(new BorderLayout());
        panelMenu.setVisible(true);
        panelMenu.setBackground(gris);

        //panel embebido en el panel principal.
        JPanel panelSuperior = new JPanel();
        panelSuperior.setLayout(new BoxLayout(panelSuperior, BoxLayout.Y_AXIS));
        panelSuperior.setBackground(gris);

        //Botón que muestra las normas del juego.
        JPanel wrapper = crearBotonInstrucciones();

        JPanel wrapper2 = crearContadorPuntos();

        //Texto que pide seleccionar el tamaño del tablero
        JLabel etiqueta = crearTextotamanoDificultadTablero();

        //Logo del juego
        JLabel iconoLabel = crearLogo();

        //Botones de los posibles tamaños del tablero
        JPanel botonesTamano = crearBotones();

        //Botones de las posibles dificultades
        JPanel botonesDificultad = crearBotonesDificultad();

        JPanel botones = new JPanel();
        botones.setLayout(new BoxLayout(botones, BoxLayout.X_AXIS));
        botones.add(botonesTamano);
        botones.add(botonesDificultad);
        botones.setBackground(gris);

        //Botón para iniciar la partida
        Button botonIniciar = crearBotonIniciar();


        panelSuperior.add(wrapper, BorderLayout.EAST);
        panelSuperior.add(wrapper2, BorderLayout.WEST);
        panelSuperior.add(Box.createVerticalStrut(40));
        panelSuperior.add(iconoLabel);
        panelSuperior.add(Box.createVerticalStrut(10));
        panelSuperior.add(etiqueta);
        panelSuperior.add(Box.createVerticalStrut(10));

        panelMenu.add(panelSuperior, BorderLayout.NORTH);
        panelMenu.add(botones, BorderLayout.CENTER);
        panelMenu.add(botonIniciar, BorderLayout.SOUTH);


        setContentPane(panelMenu);
        revalidate();
        repaint();
    }

    private JPanel crearContadorPuntos() {
        JLabel contador = new JLabel("Puntos totales: " + controladorPuntos.getPuntos());
        System.out.println(controladorPuntos.getPuntos());
        contador.setBackground(gris);
        contador.setForeground(morado);
        contador.setFont(new Font("SansSerif", Font.ITALIC, 15));
        contador.setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel wrapper = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0)); // alineado a la derecha, sin margen
        wrapper.setOpaque(false);
        wrapper.add(contador);
        return wrapper;
    }

    private Button crearBotonIniciar() {
        Button botonIniciar = new Button("Iniciar Partida");
        botonIniciar.setBackground(morado);
        botonIniciar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(tamanoSeleccionado && dificultadSeleccionada)iniciarJuego();
            }
        });
        botonIniciar.setFont(new Font("SansSerif", Font.PLAIN, 24));
        botonIniciar.setForeground(Color.white);
        return botonIniciar;
    }

    private JPanel crearBotonesDificultad() {
        JPanel botones = new JPanel();
        botones.setLayout(new BoxLayout(botones, BoxLayout.Y_AXIS));
        botones.setBackground(gris);

        JButton b5 = new JButton("Fácil \uD83C\uDF1F");
        JButton b6 = new JButton("Normal \uD83C\uDF1F \uD83C\uDF1F");
        JButton b7 = new JButton("Difícil \uD83C\uDF1F \uD83C\uDF1F \uD83C\uDF1F");
        JButton b8 = new JButton("Imposible \uD83D\uDC80");
        b5.setActionCommand("0");
        b6.setActionCommand("1");
        b7.setActionCommand("2");
        b8.setActionCommand("3");

        if(controladorPuntos.getPuntos()<5000) b8.setEnabled(false);

        Border defaultBorder = b5.getBorder();
        Border selectedBorder = new LineBorder(morado, 5);

        JButton[] arrayBotones = crearBotonesAbstract(b5, b6, b7, b8, botones);

        ActionListener listener = e -> {
            JButton botonSeleccionado = (JButton) e.getSource();
            for (JButton b : arrayBotones)
            {
                b.setBorder(defaultBorder);
            }
            botonSeleccionado.setBorder(selectedBorder);
            dificultadSeleccionada = true;
            String comando = e.getActionCommand();
            controladorLetra = new ControladorLetra(Integer.parseInt(comando));
        };

        for (JButton boton : arrayBotones) {
            boton.addActionListener(listener);
        }

        return botones;
    }

    private JButton[] crearBotonesAbstract(JButton b5, JButton b6, JButton b7, JButton b8, JPanel botones) {
        JButton[] arrayBotones = {b5, b6, b7, b8};

        for (JButton b : arrayBotones) {
            b.setAlignmentX(Component.CENTER_ALIGNMENT);
            b.setPreferredSize(new Dimension(200, 50));
            b.setMaximumSize(new Dimension(200, 50)); // evita que crezcan
            b.setFont(new Font("SansSerif", Font.PLAIN, 24));
            b.setBackground(malva);
            b.setForeground(Color.black);
            b.setFocusPainted(false);
            botones.add(b);
            botones.add(Box.createVerticalStrut(15));// separación entre botones
        }
        return arrayBotones;
    }

    private JPanel crearBotones() {
        JPanel botones = new JPanel();
        botones.setLayout(new BoxLayout(botones, BoxLayout.Y_AXIS));
        botones.setBackground(gris);

        JButton b5 = new JButton("5 letras");
        JButton b6 = new JButton("6 letras");
        JButton b7 = new JButton("7 letras");
        JButton b8 = new JButton("8 letras");
        b5.setActionCommand("5");
        b6.setActionCommand("6");
        b7.setActionCommand("7");
        b8.setActionCommand("8");

        if(controladorPuntos.getPuntos()<5000) b8.setEnabled(false);
        Border defaultBorder = b5.getBorder();
        Border selectedBorder = new LineBorder(morado, 5);

        JButton[] arrayBotones = crearBotonesAbstract(b5, b6, b7, b8, botones);

        ActionListener listener = e -> {
            JButton botonSeleccionado = (JButton) e.getSource();
            for (JButton b : arrayBotones)
            {
                b.setBorder(defaultBorder);
            }
            botonSeleccionado.setBorder(selectedBorder);
            tamanoSeleccionado = true;
            String comando = e.getActionCommand();
            tamano = Integer.parseInt(comando);
        };

        for (JButton boton : arrayBotones) {
            boton.addActionListener(listener);
        }

        return botones;
    }

    private JLabel crearLogo() {

        ImageIcon icono = new ImageIcon(Objects.requireNonNull(getClass().getResource("/icono.png")));
        Image imagenOriginal = icono.getImage();
        int nuevoAncho = 120;
        int nuevoAlto = 120;
        BufferedImage imagenEscalada = new BufferedImage(nuevoAncho, nuevoAlto, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = imagenEscalada.createGraphics();
        g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.drawImage(imagenOriginal, 0, 0, nuevoAncho, nuevoAlto, null);
        g2d.dispose();
        JLabel iconoLabel = new JLabel(new ImageIcon(imagenEscalada));
        iconoLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        return iconoLabel;
    }

    private JLabel crearTextotamanoDificultadTablero() {
        JLabel etiqueta = new JLabel("Selecciona el tamaño del tablero y la dificultad", SwingConstants.CENTER);
        etiqueta.setFont(new Font("SansSerif", Font.BOLD, 22));
        etiqueta.setForeground(morado);
        etiqueta.setAlignmentX(Component.CENTER_ALIGNMENT);
        return etiqueta;
    }

    private JPanel crearBotonInstrucciones() {
        ImageIcon icon = new ImageIcon(Objects.requireNonNull(getClass().getResource("/comojugar.png")));
        Image img = icon.getImage().getScaledInstance(35, 27, Image.SCALE_SMOOTH);
        JButton comojugar = new JButton();
        comojugar.setIcon(new ImageIcon(img));
        comojugar.setBorderPainted(false);
        comojugar.setContentAreaFilled(false);
        comojugar.setOpaque(false);
        comojugar.setPreferredSize(new Dimension(35, 27));
        comojugar.addActionListener(e -> comoJugar());
        comojugar.setAlignmentX(Component.RIGHT_ALIGNMENT);

        JPanel wrapper = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0)); // alineado a la derecha, sin margen
        wrapper.setOpaque(false);
        wrapper.add(comojugar);
        return wrapper;
    }

    /**
     * Ventana emergente que contiene las normas del juego.
     */
    private void comoJugar() {

        JDialog dialogo = new JDialog(this, "Instrucciones", true); // true = modal
        dialogo.setSize(400, 400);
        dialogo.setLocationRelativeTo(this);
        dialogo.setLayout(new BorderLayout());
        dialogo.setBackground(gris);

        JLabel mensaje = new JLabel(
                "<html><div style='text-align: center;'>"
                        + "1. Para ganar se debe formar una palabra en una de las filas, con el número de letras elegidas previamente.<br><br>"
                        + "2. Las letras se colocarán en la primera casilla libre de la fila seleccionada.<br><br>"
                        + "3. Únicamente serán válidas las palabras presentes en el diccionario, por lo tanto, no se aceptarán palabras en plural ni formas verbales que no sean el infinitivo.<br><br>"
                        + "4. Las tildes no se tienen en cuenta.<br><br>"
                        + "5. Cuanto mayor sea el nivel de dificultad, mayor probabilidad de aparición tendrán las letras menos comunes.<br><br>"
                        + "6. Los puntos obtenidos por cada victoria son 50, 100 y 150 de menor a mayor dificultad, más veinte puntos la cantidad de letras.<br><br>"
                        + "7. El modo de juego 'Imposible' y el tablero de tamaño '8 letras' se desbloquean al alcanzar los 5000 puntos.<br><br>"
                        + "</div></html>"
        );
        mensaje.setHorizontalAlignment(SwingConstants.CENTER);
        mensaje.setForeground(morado);
        dialogo.add(mensaje, BorderLayout.CENTER);
        dialogo.setVisible(true);

    }

    /**
     * Inicialización de los paneles de la ventana principal del juego.
     */
    private void iniciarJuego(){
        primerTurno = true;

        //Panel principal del área de juego
        panelTablero = new JPanel(new BorderLayout());
        panelTablero.setBackground(gris);

        //Panel embebido en el panel principal
        contenedorInferior = new JPanel();
        contenedorInferior.setLayout(new BoxLayout(contenedorInferior, BoxLayout.Y_AXIS));
        panelTablero.add(contenedorInferior, BorderLayout.SOUTH);

        //Panel embebido en el panel principal
        contenedorSuperior = new JPanel();
        contenedorSuperior.setLayout(new BorderLayout());
        panelTablero.add(contenedorSuperior, BorderLayout.NORTH);


        arrancarPrimerTurno();
    }

    /**
     * Creación de los elementos gráficos de la ventana principal del juego e inicio del primer turno.
     */
    private void arrancarPrimerTurno()
    {
        mostrarTablero();
        botonAtras();

        letras = controladorLetra.getLetras();
        mostrarLetras();
        decidirLetra();

    }

    /**
     * Creación de los elementos gráficos necesarios para que el usuario seleccione una fila
     */
    private void mostrarFila() {

        panelFila = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        panelFila.setPreferredSize(new Dimension(800, 100));

        contenedorInferior.add(panelFila, BorderLayout.NORTH);


        JLabel opcionesFila = new JLabel("Escoja una fila");
            opcionesFila.setFont(new Font("Arial", Font.BOLD, 22));
            opcionesFila.setAlignmentX(Component.CENTER_ALIGNMENT);
            opcionesFila.setForeground(morado);


        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        botones = new JButton[tamano];
        for (int i = 0; i < tamano; i++)
            {
                botones[i] = new JButton(String.valueOf(i + 1)); // opcional: empieza en 1
                botones[i].setFont(new Font("Arial", Font.BOLD, 16));
                botones[i].setPreferredSize(new Dimension(50, 40));
                panelBotones.add(botones[i]);
            }

        panelFila.add(opcionesFila, BorderLayout.NORTH);
        panelFila.add(panelBotones, BorderLayout.NORTH);

        setContentPane(panelTablero);
        revalidate();
        repaint();
        }


    /**
     * Lógica necesaria para la elección de la fila donde colocar la letra previamente seleccionada.
     */
    private void decidirFila(char letra)
    {
        panelFila.setVisible(true);
        for(int i = 0; i < tamano; i++)
        {
            int finalI = i;

            for (ActionListener al : botones[i].getActionListeners())
            {
                botones[i].removeActionListener(al);
            }
            botones[i].addActionListener(e ->
            {
                colocarLetra(finalI, letra);
                panelFila.setVisible(false);
            });
        }
    }

    /**
     *Lógica necesaria para introducir la letra en la primera casilla libre de la fila seleccionada por el usuario y para comprobar posibles victorias o derrotas.
     */
    private void colocarLetra(int filaSeleccionada, char letra) {

        if(controladorTablero.anadirLetra(filaSeleccionada, letra, tamano))
        {
            if(controladorTablero.getVictoria())
            {
                crearDialogVictoria(controladorTablero.recuperarPalabra(filaSeleccionada));


            }
            else if(controladorTablero.tableroLleno()) {crearDialogDerrota();}

            letras = controladorLetra.getLetras();
            decidirLetra();
        }
        else
        {
            crearDialogFilaCompleta();
            decidirLetra();
        }


    }

    /**
     * Creación de los elementos gráficos del diólogo que aparece cuando el usuario pierde una partida.
     */
    private void crearDialogDerrota() {

        JDialog dialogo = new JDialog(this, "Derrota", true); // true = modal
        dialogo.setSize(400, 200);
        dialogo.setLocationRelativeTo(this);
        dialogo.setLayout(new BorderLayout());
        dialogo.setBackground(gris);

        JLabel mensaje = new JLabel("Ha perdido. Inténtelo de nuevo", SwingConstants.CENTER);
        dialogo.add(mensaje, BorderLayout.CENTER);
        mensaje.setForeground(morado);

        salidaDialog(dialogo);

    }

    /**
     *Lógica para volver al menú principal cuando el usuario pierde una partida.
     */
    private void salidaDialog(JDialog dialogo) {
        JButton aceptar = new JButton("Aceptar");
        aceptar.addActionListener(e ->
        {
            dialogo.dispose();
            mostrarMenu();
        });

        dialogo.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        dialogo.addWindowListener(new java.awt.event.WindowAdapter() {
                                      @Override
                                      public void windowClosing(java.awt.event.WindowEvent e) {
                                          int respuesta = JOptionPane.showConfirmDialog(
                                                  dialogo,
                                                  "¿Seguro que quieres salir del juego?",
                                                  "Confirmar salida",
                                                  JOptionPane.YES_NO_OPTION,
                                                  JOptionPane.QUESTION_MESSAGE
                                          );

                                          if (respuesta == JOptionPane.YES_OPTION) {
                                              System.exit(0);

                                          } else {
                                              crearDialogDerrota();
                                          }
                                      }
                                  });
        dialogo.add(aceptar, BorderLayout.SOUTH);
        dialogo.setVisible(true);
    }

    /**
     * Creación de los elementos gráficos del diólogo que aparece cuando el usuario intenta colocar una letra en una fila ya completada.
     */
    private void crearDialogFilaCompleta() {
        JDialog dialogo = new JDialog(this, "", true); // true = modal
        dialogo.setSize(300, 300);
        dialogo.setLocationRelativeTo(this);
        dialogo.setLayout(new BorderLayout());
        dialogo.setBackground(gris);

        JLabel mensaje = new JLabel("La fila seleccionada está llena!", SwingConstants.CENTER);
        mensaje.setForeground(morado);
        dialogo.add(mensaje, BorderLayout.CENTER);
        dialogo.setVisible(true);

    }

    /**
     *Creación de los elementos gráficos del diólogo que aparece cuando el usuario gana una partida.
     */
    private void crearDialogVictoria(String palabraCompleta){
        JDialog dialogo = new JDialog(this, "Victoria", true); // true = modal
        dialogo.setSize(400, 200);
        dialogo.setLocationRelativeTo(this);
        dialogo.setLayout(new BorderLayout());
        dialogo.setBackground(gris);

        String puntos = String.valueOf(controladorPuntos.getPuntosPartidaActual(controladorLetra.getDificultad(), tamano));
        JLabel mensaje = new JLabel(
                "<html><div style='text-align: center;'>"
                        + "¡Enhorabuena! Ha ganado con la palabra: <b>" + palabraCompleta + "</b><br><br>"
                        + "Puntos: <b>" + puntos + "</b>"
                        + "</div></html>", SwingConstants.CENTER );
        dialogo.add(mensaje, BorderLayout.CENTER);
        mensaje.setForeground(morado);

        salidaDialog(dialogo);
    }


    /**
     * Creación de los elementos gráficos necesarios para la elección de letras.
     */
    private void mostrarLetras() {

        panelLetras = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        panelLetras.setPreferredSize(new Dimension(800, 100));

        contenedorInferior.add(panelLetras, BorderLayout.NORTH);


        JLabel opcionesLetras = new JLabel("Escoja una letra");
        opcionesLetras.setFont(new Font("Arial", Font.BOLD, 22));
        opcionesLetras.setForeground(morado);

        vocal = new JButton();
        consonante = new JButton();
        consonante.setFont(new Font("Arial", Font.BOLD, 16));
        vocal.setFont(new Font("Arial", Font.BOLD, 16));
        consonante.setPreferredSize(new Dimension(100, 60));
        vocal.setPreferredSize(new Dimension(100, 60));

        panelLetras.add(opcionesLetras, FlowLayout.LEFT);
        panelLetras.add(consonante, FlowLayout.CENTER);
        panelLetras.add(vocal, FlowLayout.CENTER);


        setContentPane(panelTablero);
        revalidate();
        repaint();

    }

    /**
     * Asignación de las letras generadas a los botones consonante y vocal y procesamiento de la opción elegida por el usuario.
     */
    private void decidirLetra() {

        panelLetras.setVisible(true);
        vocal.setText(String.valueOf(letras[0]).toUpperCase());
        consonante.setText(String.valueOf(letras[1]).toUpperCase());

        consonante.addActionListener(e ->
        {
            panelLetras.setVisible(false);
            if(primerTurno) {mostrarFila(); primerTurno = false;}
            decidirFila(letras[1]);
        });

        vocal.addActionListener(e ->
        {
            panelLetras.setVisible(false);
            if(primerTurno) {mostrarFila(); primerTurno = false;}
            decidirFila(letras[0]);
        });

    }


    /**
     * Creación de los elementos gráficos del botón para volver al menú principal.
     */
    private void botonAtras() {

        ImageIcon icon = new ImageIcon(Objects.requireNonNull(getClass().getResource("/atras.png")));
        Image img = icon.getImage().getScaledInstance(35, 27, Image.SCALE_SMOOTH);

        atras = new JButton();
        atras.setIcon(new ImageIcon(img));
        atras.setBorderPainted(false);
        atras.setContentAreaFilled(false);
        atras.setOpaque(false);
        atras.setPreferredSize(new Dimension(35, 27));
        atras.addActionListener(e -> mostrarMenu());

        contenedorSuperior.add(atras, BorderLayout.WEST);

        setContentPane(panelTablero); // reemplaza el contenido del frame
        revalidate();
        repaint();
    }


    /**
     * Establecimiento de las dimensiones del tablero y creación de sus elementos gráficos.
     */
    private void mostrarTablero() {

        crearTitulo();

        JPanel grid = new JPanel(new GridLayout(tamano, tamano, 1, 10));
        grid.setPreferredSize(new Dimension(300, 300)); // Tamaño fijo para el tablero
        grid.setMaximumSize(new Dimension(300, 300));

        controladorTablero = new ControladorTablero(tamano, grid, controladorLetra);

        JPanel panelCentro = new JPanel(new GridBagLayout());
        panelCentro.add(grid);
        panelCentro.setPreferredSize(new Dimension(300, 300)); // Tamaño fijo para el tablero
        panelCentro.setMaximumSize(new Dimension(300, 300));


        panelTablero.add(panelCentro, BorderLayout.CENTER);

        setContentPane(panelTablero); // reemplaza el contenido del frame
        revalidate();
        repaint();
    }

    /**
     * Creación de los elementos gráficos del título de la pantalla de juego.
     */
    private void crearTitulo() {

        JLabel titulo = new JLabel("Tablero de " + tamano + " x " + tamano, SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 18));
        contenedorSuperior.add(titulo, BorderLayout.NORTH);

    }


}
