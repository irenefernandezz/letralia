package Modelo;

public class LetraMedium extends Letra {

    public LetraMedium() {
        super();

        // Consonantes: leve aumento de letras raras, leve reducción de las más comunes
        pesosConsonantes = new double[]{
                0.012, // B
                0.040, // C
                0.045, // D
                0.008, // F
                0.009, // G
                0.008, // H
                0.012, // J ↑
                0.012, // K ↑
                0.035, // L
                0.040, // M
                0.050, // N ↓ un poco
                0.010, // Ñ
                0.014, // P
                0.010, // Q ↑
                0.035, // R ↓
                0.040, // S ↓
                0.038, // T ↓
                0.012, // V
                0.010, // W ↑
                0.012, // X ↑
                0.015, // Y ↑
                0.015, // Z ↑
        };

        // Vocales: más equilibradas que en fácil o difícil
        pesosVocales = new double[]{
                0.085,  // U ↑
                0.085, // I ↑
                0.080, // O (igual)
                0.070, // A ↓ leve
                0.080, // E ↓ leve
        };

        init();
    }
}
