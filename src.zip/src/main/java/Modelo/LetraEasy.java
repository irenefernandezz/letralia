package Modelo;

public class LetraEasy extends Letra{

    public LetraEasy() {
        super();
        pesosConsonantes = new double[]{0.0142, 0.0468, 0.0586, 0.0069, 0.0101, 0.0070, 0.0044,
                0.0002, 0.0497, 0.0315, 0.0671, 0.0031, 0.0251, 0.0088, 0.0687, 0.0798, 0.0463, 0.0090,
                0.0001, 0.0022, 0.0090, 0.0052};
        pesosVocales = new double[]{0.0393, 0.0625, 0.0868, 0.1253, 0.1368};
        init();
    }
}
