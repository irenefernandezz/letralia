package Modelo;

public class LetraHard extends Letra {

    public LetraHard() {
        super();

        // Consonantes: favorecemos letras poco comunes (K, Q, X, Z, W, Ñ)
        pesosConsonantes = new double[]{
                0.010, // B
                0.035, // C
                0.040, // D
                0.007, // F
                0.008, // G
                0.007, // H
                0.015, // J
                0.020, // K ↑
                0.028, // L
                0.030, // M
                0.025, // N ↓
                0.012, // Ñ ↑
                0.012, // P
                0.018, // Q ↑↑
                0.028, // R ↓
                0.030, // S ↓
                0.027, // T ↓
                0.010, // V
                0.015, // W ↑
                0.017, // X ↑
                0.018, // Y ↑
                0.020, // Z ↑
        };

        // Vocales: reducimos A y E, subimos U e I para dificultar
        pesosVocales = new double[]{
                0.090, // U ↑
                0.080, // I ↑
                0.070, // O (neutra)
                0.050, // A ↓
                0.060, // E ↓
        };

        init();
    }
}
