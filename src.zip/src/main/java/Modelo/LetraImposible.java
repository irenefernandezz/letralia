package Modelo;

import java.util.concurrent.ThreadLocalRandom;

public class LetraImposible extends Letra{

    public LetraImposible(){
        super();
        pesosConsonantes = new double[]{
                0.005, // B ↓
                0.010, // C ↓
                0.010, // D ↓
                0.004, // F ↓
                0.006, // G ↓
                0.005, // H ↓
                0.018, // J ↑
                0.030, // K ↑↑
                0.010, // L ↓
                0.012, // M ↓
                0.010, // N ↓↓
                0.020, // Ñ ↑↑
                0.008, // P ↓
                0.025, // Q ↑↑↑
                0.010, // R ↓↓
                0.008, // S ↓↓
                0.008, // T ↓↓
                0.005, // V ↓
                0.018, // W ↑
                0.020, // X ↑
                0.020, // Y ↑
                0.022, // Z ↑↑
        };

        // Vocales: MUY escasas, sobre todo A y E
        pesosVocales = new double[]{
                0.050, // U ↑
                0.040, // I ↑
                0.025, // O ↓
                0.015, // A ↓↓
                0.020, // E ↓↓
        };

        init();
    }

    @Override
    public char getVocal() {
        double R = ThreadLocalRandom.current().nextDouble();
        if (R < 0.10) return '*';
        else return super.getVocal();
    }
}
