import Modelo.*;

import java.io.*;

public class ControladorLetra{
    private Letra letra;


    private Dificultad dificultad;


    public ControladorLetra(int dificultad) {
        switch (dificultad) {
            case 0:
                this.dificultad = Dificultad.FACIL;
                letra = new LetraEasy();
                break;
                case 1:
                this.dificultad = Dificultad.MEDIA;
                letra = new LetraMedium();
                break;
                case 2:
                this.dificultad = Dificultad.DIFICIL;
                letra = new LetraHard();
                break;
                case 3:
                this.dificultad = Dificultad.IMPOSIBLE;
                letra = new LetraImposible();
                break;
                default:
                throw new IllegalArgumentException("Dificultad desconocida");

        }

    }

    public ControladorLetra() {}

    public char[] getLetras() {
        if(dificultad != Dificultad.IMPOSIBLE) return new char[]{letra.getConsonante(), letra.getVocal()};
        else {char vocal = letra.getVocal();
              if(vocal == '*') return new char[]{'*', '*'};
              else{char consonante = letra.getConsonante();
              return new char[]{consonante, vocal};}}

    }

    public Dificultad getDificultad() {return this.dificultad;}

    public boolean buscarPalabra(String palabra) {

            try (InputStream input = getClass().getResourceAsStream("/palabras.txt")) {
                if (input == null) {
                    throw new RuntimeException("No se pudo encontrar palabras.txt en el JAR");
                }

                try (BufferedReader leerArchivo = new BufferedReader(new InputStreamReader(input))) {
                    String palabraleida;
                    while ((palabraleida = leerArchivo.readLine()) != null) {
                        StringBuilder sb = new StringBuilder(palabraleida);
                        for (int i = 0; i < sb.length(); i++) {
                            char c = sb.charAt(i);
                            if (c == 'á') sb.setCharAt(i, 'a');
                            else if (c == 'é') sb.setCharAt(i, 'e');
                            else if (c == 'í') sb.setCharAt(i, 'i');
                            else if (c == 'ó') sb.setCharAt(i, 'o');
                            else if (c == 'ú') sb.setCharAt(i, 'u');
                        }
                        palabraleida = sb.toString();

                        if (palabraleida.equals(palabra)) {
                            return true;
                        }
                    }
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            return false;
        }
}
