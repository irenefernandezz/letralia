package Modelo;

public enum Dificultad {
        FACIL(0),
        MEDIA(1),
        DIFICIL(2),
        IMPOSIBLE(3);

        private final int dif;

        Dificultad(int dif) {
        this.dif = dif;
        }

        public int getDificultad() {return dif;}
}

