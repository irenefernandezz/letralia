package Modelo;

import java.util.concurrent.ThreadLocalRandom;

public abstract class Letra {
    private final char[] candidatosConsonante;
    private final char[] candidatosVocal;

    protected double[] pesosConsonantes;
    protected double[] pesosVocales;

    private double[] acumuladasConsonante;
    private double[] acumuladasVocal;
    static int NUM_VOCALES = 5;
    static int NUM_CONSONANTES = 22;

    public Letra(){
        candidatosConsonante = new char[]{'b', 'c', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'm','n', 'ñ', 'p', 'q', 'r', 's', 't',
        'v', 'w', 'x' , 'y', 'z'};
        candidatosVocal = new char[]{'u','i', 'o', 'a', 'e'};
        acumuladasConsonante = new double[NUM_CONSONANTES];
        acumuladasVocal = new double[NUM_VOCALES];

    }

    protected void init(){
        normalizar(pesosConsonantes);
        normalizar(pesosVocales);
        acumuladasVocal();
        acumuladasConsonante();
    }

    protected void acumuladasVocal() {
        double acumulado = 0.0;
        for (int i = 0; i < pesosVocales.length; i++) {
            acumulado += pesosVocales[i];
            acumuladasVocal[i] = acumulado;
        }
        acumuladasVocal[acumuladasVocal.length - 1] = 1;
    }

    protected void acumuladasConsonante() {
        double acumulado = 0.0;
        for (int i = 0; i < pesosConsonantes.length; i++) {
            acumulado += pesosConsonantes[i];
            acumuladasConsonante[i] = acumulado;
        }
        acumuladasConsonante[acumuladasConsonante.length - 1] = 1;
    }

    protected void normalizar(double[] pesos) {
        double suma = 0;
        for (double p : pesos) suma += p;      // Paso 1: calcula la suma total
        for (int i = 0; i < pesos.length; i++) {
            pesos[i] /= suma;                  // Paso 2: divide cada peso entre la suma
        }
    }



    public char getConsonante() {
        char letra;

        double R = ThreadLocalRandom.current().nextDouble();

        int i = 0;
        while (i < acumuladasConsonante.length && R >= acumuladasConsonante[i]) i++;
        letra = candidatosConsonante[i];


        return letra;
    }


    public char getVocal() {
        char letra;

        double R = ThreadLocalRandom.current().nextDouble();

        int i = 0;
        while (i < acumuladasVocal.length && R >= acumuladasVocal[i]) i++;
        letra = candidatosVocal[i];


        return letra;
    }
}
