package Modelo;

import javax.swing.*;
import java.awt.*;

public class Tablero {

    private JLabel[][] celdas;
    private int letrasPosicionadas;

    public Tablero(int tamano, JPanel grid) {

        celdas = new JLabel[tamano][tamano];

        for (int i = 0; i < tamano; i++) {
            for (int j = 0; j < tamano; j++) {

                JLabel celda = new JLabel(" ", SwingConstants.CENTER);
                celda.setFont(new Font("Monospaced", Font.BOLD, 20));
                celda.setBorder(BorderFactory.createLineBorder(new Color(180, 150, 255)));
                grid.add(celda);
                celda.setText(null);
                celdas[i][j] = celda;
            }
        }

        letrasPosicionadas = 0;
    }



    public int getDimension() {
        return celdas.length;
    }

    public void setLetra(int x, int y, char letra) {celdas[x][y].setText(String.valueOf(letra));}

    public JLabel[][] getCeldas(){return this.celdas;}


    public void setLetrasPosicionadas() {this.letrasPosicionadas++;}

    public boolean tableroLleno() {
        return letrasPosicionadas == Math.pow(celdas.length, 2);
    }


    public String PalabraCompleta(int x) {
        StringBuilder palabra = new StringBuilder();
        for (int i = 0; i < getDimension(); i++)
        {
            palabra.append(getCeldas()[x][i].getText());
        }
        return palabra.toString();
    }

    public int posicionVaciaEnFila(int filaSeleccionada, int tamano) {
        boolean encontrado = false;
        int i = 0;
        int fila = -1;
        while (!encontrado && i < tamano) {
            if(celdas[filaSeleccionada][i].getText() == null) {
                encontrado = true;
                fila = i;
            }
            i++;
        }
        return fila;
    }
}
