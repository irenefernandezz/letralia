package Modelo;

import java.io.*;

public class Puntos {
    private int totalPuntos;
    private static Puntos puntosSingleton;

    // Ruta externa donde se guardarán los puntos
    private static final String RUTA_PUNTOS = System.getProperty("java.io.tmpdir") + File.separator + "Puntos.txt";
    private Puntos() {
        File archivoExterno = new File(RUTA_PUNTOS);

        // Si no existe el archivo externo, intentamos copiarlo desde el JAR
        if (!archivoExterno.exists()) {
            try (InputStream input = getClass().getResourceAsStream("/Puntos.txt")) {
                if (input == null) {
                    // Si no está en el jar, inicializamos con 0
                    System.err.println("No se encontró Puntos.txt en el JAR, inicializando puntos a 0");
                    totalPuntos = 0;
                    return;
                }

                // Copiar el contenido del JAR al archivo externo
                try (FileOutputStream output = new FileOutputStream(archivoExterno)) {
                    byte[] buffer = new byte[1024];
                    int bytesRead;
                    while ((bytesRead = input.read(buffer)) != -1) {
                        output.write(buffer, 0, bytesRead);
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
                totalPuntos = 0;
                return;
            }
        }

        // Ahora leemos el archivo externo para inicializar totalPuntos
        try (BufferedReader br = new BufferedReader(new FileReader(archivoExterno))) {
            String linea = br.readLine();
            if (linea != null) {
                try {
                    totalPuntos = Integer.parseInt(linea);
                } catch (NumberFormatException e) {
                    System.err.println("Formato de Puntos.txt inválido, inicializando a 0");
                    totalPuntos = 0;
                }
            } else {
                totalPuntos = 0;
            }
        } catch (IOException e) {
            e.printStackTrace();
            totalPuntos = 0;
        }
    }

    public static Puntos getInstancia() {
        if (puntosSingleton == null) {
            puntosSingleton = new Puntos();
        }
        return puntosSingleton;
    }

    public int getTotalPuntos() {
        return totalPuntos;
    }

    public int calcularPuntos(Dificultad dificultad, int tamano) {
        return ((dificultad.getDificultad() * 50) + 50) + (20 * tamano);
    }
    public void setTotalPuntos(int puntos) {
        this.totalPuntos += puntos;

        File archivoExterno = new File(RUTA_PUNTOS);

        try (FileWriter fw = new FileWriter(archivoExterno, false)) { // false = sobrescribir
            fw.write(String.valueOf(totalPuntos));
            System.out.println("Puntos guardados correctamente: " + totalPuntos);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
