import Modelo.Dificultad;
import Modelo.Puntos;

public class ControladorPuntos {
    private Puntos puntos;

    public ControladorPuntos() {
       puntos = Puntos.getInstancia();
    }

    public int getPuntos(){return puntos.getTotalPuntos();}

    public int getPuntosPartidaActual(Dificultad dificultad, int tamano){return puntos.calcularPuntos(dificultad, tamano);}

    public void sumarPuntos(Dificultad dificultad, int tamano) {
    puntos.setTotalPuntos(getPuntosPartidaActual(dificultad, tamano));}
}
