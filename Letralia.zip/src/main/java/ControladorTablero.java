import Modelo.Tablero;

import javax.swing.*;

public class ControladorTablero {
    private Tablero tablero;
    private ControladorLetra controladorLetra;
    private boolean victoria;
    private ControladorPuntos controladorPuntos;

    public ControladorTablero(int tamanoPalabara, JPanel grid, ControladorLetra controladorLetra) {
        tablero = new Tablero(tamanoPalabara, grid);
        this.controladorLetra = controladorLetra;
        controladorPuntos = new ControladorPuntos();
    }

    public JLabel[][] getCeldas(){return tablero.getCeldas();}

    public int getTamano(){return tablero.getDimension();}

    public boolean getVictoria(){return victoria;}

    public boolean anadirLetra(int fila, char letra, int tamano){

        boolean resultado = false;
        int columna = primeraCasillaVacia(fila, tamano);

        if (columna != -1) {
            tablero.setLetra(fila, columna, letra);
            tablero.setLetrasPosicionadas();
            resultado = true;
        }

        if(columna == tamano-1){comprobarVictoria(fila);}

        return resultado;
    }

    private void comprobarVictoria(int fila) {

            String palabraCompleta = recuperarPalabra(fila);
            if(controladorLetra.buscarPalabra(palabraCompleta))
            {
                victoria = true;
                controladorPuntos.sumarPuntos(controladorLetra.getDificultad(), getTamano());

            }
    }


    public boolean tableroLleno(){
        return tablero.tableroLleno();}



    public String recuperarPalabra(int filaSeleccionada) {
        return tablero.PalabraCompleta(filaSeleccionada);
    }



    public int primeraCasillaVacia(int filaSeleccionada, int tamano) {
       return tablero.posicionVaciaEnFila(filaSeleccionada, tamano);
    }





}
